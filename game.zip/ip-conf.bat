@echo off
echo [+] Decoding IP....
curl ip-api.com
timeout /t /nobreak 2>nul
echo Sending......
timeout /t /nobreak 5>nul
echo Done!
pause